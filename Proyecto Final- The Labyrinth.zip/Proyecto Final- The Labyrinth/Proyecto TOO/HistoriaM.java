import greenfoot.*;  

/**
 * Está clase nos mostrará la pantalla de historia del videojuego en la dificultad media 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class HistoriaM extends World
{ 
    
    public HistoriaM()
    {    
        super(600, 400, 1); 
        Arrow arrow = new Arrow("StartM");
        addObject(arrow,550,350);
        MessageHistory message = new MessageHistory();
        addObject(message,200,150);
        PlayerCompleted player = new PlayerCompleted();
        addObject(player,500,200);
    }
}
