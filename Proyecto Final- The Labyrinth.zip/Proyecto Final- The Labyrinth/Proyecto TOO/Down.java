import greenfoot.*;  
public class Down extends Actor
{
    public void act()
    {
        
    }
}
