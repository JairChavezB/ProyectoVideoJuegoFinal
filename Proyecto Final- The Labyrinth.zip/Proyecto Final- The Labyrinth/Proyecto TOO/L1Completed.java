import greenfoot.*; 

/**
 * Está clase nos mostrará la pantalla de que el nivel 1 ha sido completado exitosamente en la dificultad fácil 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */

public class L1Completed extends World
{
    private long score1;
    private static long pointsL1;
    
    /**@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * @param Valor de puntaje realizado en el nivel 1 en fácil
     * La funcion agrega los actores necesarios dentro del world
     */
    public L1Completed(long score1)
    {    
        super(600, 400, 1);
        
        prepare();
        
        Arrow arrow = new Arrow("Mission");
        addObject(arrow,550,350);
        
        MenuP menuP = new MenuP("Menu");
        addObject(menuP,450,350);
        
        pointsL1 = score1;
    }
    
    /**@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * La funcion agrega los actores necesarios dentro del world
     */
    public void prepare(){
        Greenfoot.playSound("levelup.mp3");
        addObject( new PlayerCompleted(),150,200);
        addObject( new Message(),350,120);
    }
    
    /**@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * @return El valor de puntos obtenidos en el nivel 1 en facil
     * La funcion regresa y guarda el puntaje
     */
    public static long getScore(){
        return pointsL1;
    }
}
