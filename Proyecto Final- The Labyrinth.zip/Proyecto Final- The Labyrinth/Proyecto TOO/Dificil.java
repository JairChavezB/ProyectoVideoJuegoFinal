import greenfoot.*;  

/**
 * Está clase aparecerá en las dificultades y nos ayudará a poder entrar en el world de la dificultad que se desea
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class Dificil extends Button
{
    public void clickButton()
    {
        if(Greenfoot.mouseClicked(this)){
            Greenfoot.setWorld(new Historia());
        }
    }
}
