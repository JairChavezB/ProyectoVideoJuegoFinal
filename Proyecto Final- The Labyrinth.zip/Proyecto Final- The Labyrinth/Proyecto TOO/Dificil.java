import greenfoot.*;  
public class Dificil extends Button
{
    public void clickButton()
    {
        if(Greenfoot.mouseClicked(this)){
            Greenfoot.setWorld(new Historia());
        }
    }
}
