import greenfoot.*;

/**
 * Está clase aparecerá en distintas pantallas y nos ayudará a ir al menú principal
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class MenuP extends Button
{
    private String world;
    
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * @param Indica el mundo del nivel que sigue 
     */
    public MenuP(String world){
        super();
        this.world = world;
    }
    
   /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * Al momento de presionar el actor con el click manda al jugador al menú principal
     */ 
   public void clickButton(){
        
        if(Greenfoot.mouseClicked(this)){
            Greenfoot.delay(10);
            switch(world){
                case "Menu":
                    Greenfoot.playSound("boton.mp3");
                    Greenfoot.setWorld(new Menu());
                    break;
                }
        }
    }
}
