import greenfoot.*;  

/**
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public abstract class Button extends Actor
{
    public void act()
    {
        clickButton();
    }
    
    public abstract void clickButton();
}
