import greenfoot.*;  

public abstract class Button extends Actor
{
    public void act()
    {
        clickButton();
    }
    
    public abstract void clickButton();
}
