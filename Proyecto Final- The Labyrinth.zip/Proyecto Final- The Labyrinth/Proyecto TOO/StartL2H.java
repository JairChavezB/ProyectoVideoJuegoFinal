import greenfoot.*;  

/**
 * Está clase nos mostrará la pantalla de inicio para el nivel 2 en la dificultad difícil 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class StartL2H extends World
{
    private GreenfootSound sound;
    private String song;
    
    public StartL2H()
    {    
        super(600, 400, 1); 
        song = "levelup.mp3";
        sound = new GreenfootSound(song);
        prepare();
        
        Arrow arrow = new Arrow("Level2H");
        addObject(arrow,550,350);
    }
    
    public void prepare(){
        sound.play();
        IntroL2 intro2 = new IntroL2();
        addObject(intro2,300,200);
        LevelTwo level2 = new LevelTwo();
        addObject(level2,300,50);
        
        
    }
}
