import greenfoot.*;  

/**
 * Está clase nos mostrará la pantalla de que el nivel 2 ha sido completado exitosamente en la dificultad fácil 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class L2Completed extends World
{
    private long score2;
    private static long pointsL2;
    Home home = new Home();
    
    public L2Completed(long score2)
    {    
        super(600, 400, 1);
        prepare();
        
        Arrow arrow = new Arrow("Mission2");
        addObject(arrow,550,350);
        
        MenuP menuP = new MenuP("Menu");
        addObject(menuP,450,350);
        
        pointsL2 = score2;
    }
    
    public void prepare(){
        Greenfoot.playSound("levelup.mp3");
        addObject( new PlayerCompleted(),150,200);
        addObject( new Message2(),350,120);
    }
    
    public static long getScore(){
        return pointsL2;
    }
}
