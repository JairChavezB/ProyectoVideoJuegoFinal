import greenfoot.*; 

/**
 * Está clase es el villano que aparecerá en el nivel 2 en la dificultad media 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class BeeM extends Actor
{
    private int xPosition;
    private int horizontalMove=2;
    
    public BeeM(){
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()/22;
        int myNewWidth = (int)myImage.getWidth()/22;
        myImage.scale(myNewWidth, myNewHeight);
    }
    
   public void act(){
        move();
    }
    
   private void move(){
        move(1);
        
        Actor actor = getOneIntersectingObject (Pared.class);
        if((actor != null)){
            turn(10);
        }
        
        actor = getOneIntersectingObject (ParedL2.class);
        if((actor != null)){
            turn(10);
        }
    }
    
    
    
}
