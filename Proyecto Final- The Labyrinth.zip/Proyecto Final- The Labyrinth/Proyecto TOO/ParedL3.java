import greenfoot.*;  

/**
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class ParedL3 extends Actor
{
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * La funcion prepara la imagen para que tenga el tamaño adecuado en el mundo
     */
    public ParedL3(){
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()/17;
        int myNewWidth = (int)myImage.getWidth()/17;
        myImage.scale(myNewWidth, myNewHeight);
    }
}
