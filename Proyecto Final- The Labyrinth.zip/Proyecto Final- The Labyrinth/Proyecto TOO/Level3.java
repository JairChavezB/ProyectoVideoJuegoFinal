import greenfoot.*; 

/**
 * Está clase nos ayudará a construir el mundo del nivel 3 en la dificultad fácil 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class Level3 extends World
{
    
    
    public Level3()
    {    
        
        super(600, 400, 1); 
        prepareLevel3();
    }
    
    /*@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * La funcion inserta los actores necesarios para el world nivel 3 facil
     */
    private void prepareLevel3(){
        addObject(new Player3(),40,350);
        addObject(new Door(),590,360);
        
        addObject(new Coin(),55,30);
        addObject(new Coin(),55,60);
        addObject(new Coin(),55,90);
        
        addObject(new Coin(),35,250);
        addObject(new Coin(),35,220);
        addObject(new Coin(),35,280);
        
        addObject(new Coin(),115,370);
        addObject(new Coin(),115,280);
        addObject(new Coin(),115,310);
        addObject(new Coin(),115,340);
        
        addObject(new Coin(),340,250);
        addObject(new Coin(),340,280);
        addObject(new Coin(),340,310);
        
        addObject(new Coin(),500,300);
        addObject(new Coin(),500,330);
        addObject(new Coin(),500,360);
        
        addObject(new Coin(),130,40);
        addObject(new Coin(),130,70);
        
        addObject(new Coin(),400,180);
        addObject(new Coin(),430,210);
        
        addObject(new Coin(),530,200);
        addObject(new Coin(),560,230);
        
        addObject(new Coin(),340,45);
        addObject(new Coin(),370,45);
        addObject(new Coin(),400,45);
        addObject(new Coin(),430,45);
        
        addObject(new Coin(),560,40);
        addObject(new Coin(),560,70);
        addObject(new Coin(),560,100);
        
        addObject(new Coin(),350,110);
        addObject(new Coin(),350,140);
        addObject(new Coin(),350,170);
        
        addObject(new Coin(),260,200);
        addObject(new Coin(),290,200);
        addObject(new Coin(),320,200);
        addObject(new Coin(),350,200);
        
        addObject(new Spider(),70,210);
        addObject(new Spider(),480,300);
        addObject(new SpiderN(),410,190);
        addObject(new SpiderN(),270,340);
        addObject(new SpiderN(),60,130);
        addObject(new SpiderN(),250,50);
        
         ParedL3 pared = new ParedL3();
        addObject(pared,80,100);
        ParedL3 paredq = new ParedL3();
        addObject(paredq,200,100);
        
        for(int x = 15; x<700; x+=18){
            ParedL3 paredl3 = new ParedL3();
            addObject(paredl3,x,10);
            paredl3 = new ParedL3();
            addObject(paredl3,x,390);
        }
        
        for(int y = 30; y<600; y+=18){
            ParedL3 paredl3 = new ParedL3();
            addObject(paredl3,10,y);
        }
        
        for(int y = 40; y<325; y+=18){
            ParedL3 paredl3 = new ParedL3();
            addObject(paredl3,590,y);
        }
        
        //V Arriba a la derecha
        for(int y = 30; y<80; y+=18){
            ParedL3 paredl3 = new ParedL3();
            addObject(paredl3,460,y);
        }
        
        //V abajo antes de en medio
        for(int y = 230; y<320; y+=18){
            ParedL3 paredl3 = new ParedL3();
            addObject(paredl3,300,y);
        }
        
        //V Abajo 1ro
        for(int y = 250; y<330; y+=18){
            ParedL3 paredl3 = new ParedL3();
            addObject(paredl3,80,y);
        }
        
        //V abjo 2do
        for(int y = 240; y<320; y+=18){
            ParedL3 paredl3 = new ParedL3();
            addObject(paredl3,150,y);
        }
        
        //
        for(int y = 20; y<100; y+=18){
            ParedL3 paredl3 = new ParedL3();
            addObject(paredl3,100,y);
        }
        
        //V Arriba 2do
        for(int y = 20; y<100; y+=18){
            ParedL3 paredl3 = new ParedL3();
            addObject(paredl3,200,y);
        }
        
        //V 3ro abajo
        for(int y = 290; y<500; y+=18){
            ParedL3 paredl3 = new ParedL3();
            addObject(paredl3,230,y);
        }
        
        // V abajo ultimo
        for(int y = 350; y<500; y+=18){
            ParedL3 paredl3 = new ParedL3();
            addObject(paredl3,450,y);
        }
        
        for(int y = 365; y<500; y+=18){
            ParedL3 paredl3 = new ParedL3();
            addObject(paredl3,340,y);
        }
        
        //V arriba 3ro
        for(int y = 100; y<160; y+=18){
            ParedL3 paredl3 = new ParedL3();
            addObject(paredl3,320,y);
        }
        
        // V Medio 
        for(int y = 150; y<310; y+=18){
            ParedL3 paredl3 = new ParedL3();
            addObject(paredl3,380,y);
        }
        
        //
        for(int x=80; x<170; x+=18){
            ParedL3 paredl3 = new ParedL3();
            addObject(paredl3,x,230);
        }
        
        //H 1ro medio 
        for(int x=100; x<260; x+=18){
            ParedL3 paredl3 = new ParedL3();
            addObject(paredl3,x,160);
        }
        
        
        for(int x=100; x<150; x+=18){
            ParedL3 paredl3 = new ParedL3();
            addObject(paredl3,x,100);
        }
        
        
        for(int x=320; x<490; x+=18){
            ParedL3 paredl3 = new ParedL3();
            addObject(paredl3,x,80);
        }
        
        
        for(int x=230; x<420; x+=18){
            ParedL3 paredl3 = new ParedL3();
            addObject(paredl3,x,225);
        }
        
        for(int x=500; x<595; x+=18){
            ParedL3 paredl3 = new ParedL3();
            addObject(paredl3,x,260);
        }
        
        for(int x=400; x<595; x+=18){
            ParedL3 paredl3 = new ParedL3();
            addObject(paredl3,x,150);
        }
    }
}
