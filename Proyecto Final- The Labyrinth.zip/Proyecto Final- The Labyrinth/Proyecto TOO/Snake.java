import greenfoot.*;  

/**
 * Está clase es el villano que aparecerá en el nivel 1 en la dificultad fácil 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class Snake extends Actor
{
    private int xPosition;
    private int horizontalMove=2;
    private int life = 6;
    
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * La funcion prepara la imagen para que tenga el tamaño adecuado en el mundo
     */
    public Snake(){
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()/75;
        int myNewWidth = (int)myImage.getWidth()/75;
        myImage.scale(myNewWidth, myNewHeight);
    }
    
    public void act(){
        if(life ==0){
            getWorld().removeObject(this);
        }
        move();
    }
    
    /**
    * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * La funcion hace que la snake se mueva y al momento de tocar la pared realice un giro
     */
    private void move(){
        move(1);
        
        Actor actor = getOneIntersectingObject (Pared.class);
        if((actor != null)){
            turn(10);
        }
    }
    
    public void add(int score)
    {
        life += score;
    }
    
    public int getValue()
    {
        return life;
    }
    
}