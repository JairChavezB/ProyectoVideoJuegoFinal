import greenfoot.*;  

/**
 * Está clase nos mostrará la pantalla de historia del videojuego en la dificultad fácil 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */ 
public class Historia extends World
{ 
    
    public Historia()
    {    
        super(600, 400, 1); 
        Arrow arrow = new Arrow("Start1");
        addObject(arrow,550,350);
        MessageHistory message = new MessageHistory();
        addObject(message,200,150);
        PlayerCompleted player = new PlayerCompleted();
        addObject(player,500,200);
    }
}
