import greenfoot.*;  

/**
 * Está clase nos mostrará la pantalla de que el nivel 3 ha sido completado exitosamente en la dificultad difícil 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class L3CompletedH extends World
{
    private long score3;
    private static long pointsL3;
    Home home = new Home();
    
    /**@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * @param Valor de puntaje realizado en el nivel 3 en dificil
     * La funcion agrega los actores necesarios dentro del world
     */
    public L3CompletedH(long score3)
    {    
        super(600, 400, 1);
        prepare();
        
        Arrow arrow = new Arrow("Mission3H");
        addObject(arrow,550,350);
        pointsL3 = score3;
    }
    
    /**@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * La funcion agrega los actores necesarios dentro del world
     */
    public void act(){
        if(Greenfoot.mouseClicked(home)){
            Greenfoot.playSound("boton.mp3");
            Greenfoot.setWorld(new Menu());
        }
    }
    
    /**@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * La funcion agrega los actores necesarios dentro del world
     */
    public void prepare(){
        Greenfoot.playSound("levelup.mp3");
        addObject( new PlayerCompleted(),150,200);
        addObject( new MessageFinal(),350,120);
        addObject(home,450,350);
    }
    
    /**@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * @return El valor de puntos obtenidos en el nivel 3 en dificil
     * La funcion regresa y guarda el puntaje
     */
    public static long getScore(){
        return pointsL3;
    }
}
