import greenfoot.*; 

/**
 * Está clase nos mostrará la pantalla de inicio para el nivel final en la dificultad media 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */ 
public class StartFinalM extends World
{
    
    public StartFinalM()
    {   
        super(600, 400, 1);
        Greenfoot.playSound("levelup.mp3");
        
        prepare();
        
        Arrow arrow = new Arrow("LevelFinalM");
        addObject(arrow,550,350);
    }
    
    public void prepare(){
        IntroF introf = new IntroF();
        addObject(introf,300,200);
        LevelF levelf = new LevelF();
        addObject(levelf,300,50);
    }
}
