import greenfoot.*;
import java.time.*;  

/**
 * Está clase nos ayudará a construir el mundo del nivel final en la dificultad media 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class LevelFinalM extends World
{
    private GreenfootSound sound;
    private String song;
    private Counter lifeHero = new Counter("Life : ");
    private Counter lifevVillain = new Counter("Boss life : ");
    private Instant start;
    private Instant end;
    
    public void act(){
        sound.play();
        if(lifeHero.getValue()==0){
            sound.stop();
            Greenfoot.setWorld(new GameOver());
        }
        if((lifevVillain.getValue()==0)){
            end = Instant.now();
            sound.stop();
            Greenfoot.setWorld(new FinallyM(3));
        }
    }

    public LevelFinalM()
    {    
        super(600, 400, 1); 
        prepare();
        song = "musica.mp3";
        sound = new GreenfootSound(song);
    }
    
    public void prepare()
    {
        start = Instant.now();
        Player4 player4 = new Player4();
        addObject(player4,30,355);
        Floor floor = new Floor();
        addObject(floor,300,392);
        Hawkmoth hawkMoth = new Hawkmoth();
        addObject(hawkMoth,570,355);

        addObject(lifeHero, 100, 30);
        lifeHero.setValue(5);
        
        addObject(lifevVillain, 500, 30);
        lifevVillain.setValue(20);
    }
}
