import greenfoot.*;  

/**
 * Está clase se mostrará en controles, servirá para regresar al menú 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class Back extends Actor
{
    
}
