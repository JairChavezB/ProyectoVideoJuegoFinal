import greenfoot.*;  

/**
 * Está clase aparecerá en menú y nos ayudará a poder entrar en el world de Control
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class Controls extends Button
{

    public void clickButton()
    {
        if(Greenfoot.mouseClicked(this)){
            Greenfoot.setWorld(new Control());
        }
    }
}
