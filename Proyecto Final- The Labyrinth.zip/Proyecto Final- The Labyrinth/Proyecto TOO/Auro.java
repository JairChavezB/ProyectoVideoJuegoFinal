import greenfoot.*; 

/**
 * Está clase nos mostrará una imagen para el world Finally 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */ 
public class Auro extends Actor
{
    public Auro(){
        
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()/2;
        int myNewWidth = (int)myImage.getWidth()/2;
        myImage.scale(myNewWidth, myNewHeight);
    }
}
