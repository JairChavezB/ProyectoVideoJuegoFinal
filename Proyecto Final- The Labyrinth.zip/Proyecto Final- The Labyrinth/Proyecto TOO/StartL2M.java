import greenfoot.*;  

/**
 * Está clase nos mostrará la pantalla de inicio para el nivel 2 en la dificultad media 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class StartL2M extends World
{
    private GreenfootSound sound;
    private String song;
    
    public StartL2M()
    {    
        super(600, 400, 1); 
        song = "levelup.mp3";
        sound = new GreenfootSound(song);
        prepare();
        
        Arrow arrow = new Arrow("Level2M");
        addObject(arrow,550,350);
    }
    
    /*@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * La funcion acomoda los actores necesarios dentro del world
     */
    public void prepare(){
        sound.play();
        IntroL2 intro2 = new IntroL2();
        addObject(intro2,300,200);
        LevelTwo level2 = new LevelTwo();
        addObject(level2,300,50);
        
        
    }
}
