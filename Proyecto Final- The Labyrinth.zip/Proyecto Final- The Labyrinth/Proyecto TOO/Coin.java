import greenfoot.*; 

/**
 * Está clase son las monedas que darán el score en todos los niveles 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class Coin extends Actor
{
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * La funcion prepara la imagen para que tenga el tamaño adecuado en el mundo
     */
    public Coin(){
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()/22;
        int myNewWidth = (int)myImage.getWidth()/22;
        myImage.scale(myNewWidth, myNewHeight);
    }
}
