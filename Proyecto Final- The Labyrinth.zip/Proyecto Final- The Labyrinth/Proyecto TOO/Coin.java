import greenfoot.*; 


public class Coin extends Actor
{
    public Coin(){
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()/22;
        int myNewWidth = (int)myImage.getWidth()/22;
        myImage.scale(myNewWidth, myNewHeight);
    }
    
    public void act()
    {
        
    }
}
