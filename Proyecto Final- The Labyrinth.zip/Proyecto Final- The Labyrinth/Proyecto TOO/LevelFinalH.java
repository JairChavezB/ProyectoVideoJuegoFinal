import greenfoot.*;
import java.time.*; 
 
/**
 * Está clase nos ayudará a construir el mundo del nivel final en la dificultad difícil 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class LevelFinalH extends World
{
    private GreenfootSound sound;
    private String song;
    private Counter lifeHero = new Counter("Life : ");
    private Counter lifevVillain = new Counter("Boss life : ");
    private Instant start;
    private Instant end;
    
    /*@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * La funcion indica que si la vida del jugador llega a 0 es GameOver o del enemigo final es cumplir la mision
     */
    public void act(){
        sound.play();
        if(lifeHero.getValue()==0){
            sound.stop();
            Greenfoot.setWorld(new GameOver());
        }
        if((lifevVillain.getValue()==0)){
            end = Instant.now();
            sound.stop();
            Greenfoot.setWorld(new FinallyH(3));
        }
    }

    /*@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * La funcion inserta los actores necesarios para el world 
     */
    public LevelFinalH()
    {    
        super(600, 400, 1); 
        prepare();
        song = "musica.mp3";
        sound = new GreenfootSound(song);
    }
    
    /*@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * La funcion inserta los actores necesarios para el world 
     */
    public void prepare()
    {
        start = Instant.now();
        Player4 player4 = new Player4();
        addObject(player4,30,355);
        Floor floor = new Floor();
        addObject(floor,300,392);
        Hawkmoth hawkMoth = new Hawkmoth();
        addObject(hawkMoth,570,355);

        addObject(lifeHero, 100, 30);
        lifeHero.setValue(3);
        
        addObject(lifevVillain, 500, 30);
        lifevVillain.setValue(20);
    }
}
