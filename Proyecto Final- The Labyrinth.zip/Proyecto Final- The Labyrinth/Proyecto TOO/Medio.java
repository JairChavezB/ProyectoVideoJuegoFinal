import greenfoot.*; 

public class Medio extends Button
{
    public void clickButton()
    {
        if(Greenfoot.mouseClicked(this)){
            Greenfoot.setWorld(new Historia());
        }
    }
}
