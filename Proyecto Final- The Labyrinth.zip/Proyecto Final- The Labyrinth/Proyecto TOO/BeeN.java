import greenfoot.*;  

/**
 * Está clase es el villano que aparecerá en el nivel 2 de cualquier dificultad  
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class BeeN extends Actor
{
    private int xPosition;
    private int horizontalMove=1;
    
    public BeeN(){
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()/22;
        int myNewWidth = (int)myImage.getWidth()/22;
        myImage.scale(myNewWidth, myNewHeight);
    }
    
    public void act(){
        move();
    }
    
    public void move(){
        xPosition=getX();
        
        Actor actor = getOneIntersectingObject (ParedL2.class);
        if((actor != null)){
            horizontalMove *= -1;
        }
        
        setLocation(xPosition - horizontalMove,getY());
    }
    
    
}
