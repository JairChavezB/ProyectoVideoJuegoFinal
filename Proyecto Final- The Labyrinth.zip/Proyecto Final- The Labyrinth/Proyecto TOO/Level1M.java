import greenfoot.*;  

/**
 * Está clase nos ayudará a construir el mundo del nivel 1 en la dificultad media 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class Level1M extends World
{
    Snake snake1 = new Snake();
    public Level1M()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1);
        preparaLevel1();
    }
    
    /*@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * La funcion inserta los actores necesarios para el world nivel 1 medio
     */
    private void preparaLevel1(){
        addObject(new PlayerM(),40,350);
        addObject(new Pared(),450,290);
        
        addObject(new Door(),580,50);//580, 350
        
        addObject(new Coin(),135,125);
        addObject(new Coin(),160,125);
        addObject(new Coin(),400,350);
        addObject(new Coin(),430,350);
        addObject(new Coin(),460,350);
        addObject(new Coin(),490,350);
        
        addObject(new Coin(),100,350);
        addObject(new Coin(),130,350);
        addObject(new Coin(),160,350);
        
        addObject(new Coin(),240,230);
        addObject(new Coin(),240,260);
        addObject(new Coin(),240,290);
        
        
        addObject(new Coin(),45,190);
        addObject(new Coin(),45,160);
        addObject(new Coin(),45,130);
        addObject(new Coin(),45,100);
        
        addObject(new Coin(),410,40);
        addObject(new Coin(),440,40);
        addObject(new Coin(),470,40);
        
        addObject(new Coin(),420,160);
        addObject(new Coin(),450,160);
        addObject(new Coin(),315,330);
        addObject(new Coin(),315,360);
        
        addObject(new Coin(),110,50);
        addObject(new Coin(),140,50);
        addObject(new Coin(),170,50);
        
        
        addObject(new SnakeM(),450,90);
        addObject(new SnakeM(),555,240);
        addObject(new SnakeM(),50,245);
        addObject(new SnakeM(),150,220);
        addObject(new SnakeN(),200,120);
        addObject(new SnakeN(),320,280);
        
        for(int x = 15; x<700; x+=20){
            Pared pared = new Pared();
            addObject(pared,x,10);
            pared = new Pared();
            addObject(pared,x,390);
        }
        
        for(int y = 30; y<600; y+=20){
            Pared pared = new Pared();
            addObject(pared,10,y);
        }
        
        for(int y = 260; y<310; y+=20){//ññ
            Pared pared = new Pared();
            addObject(pared,450,y);
        }
        
        for(int y = 90; y<600; y+=20){
            Pared pared = new Pared();
            addObject(pared,590,y);
        }
        
        for(int y = 90; y<200; y+=20){
            Pared pared = new Pared();
            addObject(pared,75,y);
        }
        
        for(int x = 80; x<220; x+=20){
            Pared pared = new Pared();
            addObject(pared,x,90);
        }
        
        for(int x = 150; x<200; x+=20){//ñ
            Pared pared = new Pared();
            addObject(pared,x,150);
        }
        
        for(int x = 75; x<200; x+=20){ 
            Pared pared = new Pared();
            addObject(pared,x,260);
        }
        
        for(int y = 30; y<200; y+=20){
            Pared pared = new Pared();
            addObject(pared,500,y);
        }
        
        for(int y = 230; y<500; y+=20){
            Pared pared = new Pared();
            addObject(pared,280,y);
        }
        
        for(int y = 150; y<250; y+=20){
            Pared pared = new Pared();
            addObject(pared,200,y);
        }
        
        for(int x =30; x<150; x+=20){
            Pared pared = new Pared();
            addObject(pared,x,320);
        }
        
        for(int y = 250; y<320; y+=20){ 
            Pared pared = new Pared();
            addObject(pared,200,y);
        }
        
         for(int y = 5; y<90; y+=20){
            Pared pared = new Pared();
            addObject(pared,200,y);
        }
        
        for(int y = 5; y<80; y+=20){
            Pared pared = new Pared();
            addObject(pared,290,y);
        }
        
        for(int x =200; x<290; x+=20){ 
            Pared pared = new Pared();
            addObject(pared,x,230);
        }
        
        for(int x =370; x<510; x+=20){
            Pared pared = new Pared();
            addObject(pared,x,70);
        }
        
        for(int x =260; x<360; x+=20){
            Pared pared = new Pared();
            addObject(pared,x,145);
        }
        
        for(int y = 145; y<250; y+=20){
            Pared pared = new Pared();
            addObject(pared,350,y);
        }
        
        for(int y = 330; y<400; y+=20){
            Pared pared = new Pared();
            addObject(pared,350,y);
        }
        
        for(int x=350; x<520; x+=20){
            Pared pared = new Pared();
            addObject(pared,x,315);
        }
        
        for(int x=350; x<520; x+=20){
            Pared pared = new Pared();
            addObject(pared,x,200);
        }
    }
}
