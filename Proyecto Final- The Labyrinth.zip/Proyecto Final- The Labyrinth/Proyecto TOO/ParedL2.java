import greenfoot.*;  
public class ParedL2 extends Actor
{
    public ParedL2(){
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()/30;
        int myNewWidth = (int)myImage.getWidth()/30;
        myImage.scale(myNewWidth, myNewHeight);
    }
    
    public void act()
    {
        
    }
}
