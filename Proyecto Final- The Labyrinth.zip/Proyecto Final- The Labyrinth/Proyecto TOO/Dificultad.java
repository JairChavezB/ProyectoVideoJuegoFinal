import greenfoot.*;  

/**
 * Clase Dificultad nos ayudara a mostrar el mundo en donde tenemos las opciones de dificultad que tendrá el jugador para poder 
 * elegir alguna
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */ 

public class Dificultad extends World
{
    private GreenfootSound sound;
    private String song;
    Facil facil = new Facil();
    Medio medio = new Medio();
    Dificil dificil = new Dificil();
    
    public Dificultad()
    {   
        super(600, 400, 1); 
        song = "jungle.mp3";
        sound = new GreenfootSound(song);
        preparaMundo();
    }
    
    public void act(){
        sound.play();
        if(Greenfoot.mouseClicked(facil)){
            Greenfoot.playSound("boton.mp3");
            Greenfoot.setWorld(new Historia());
            sound.stop();
        } 
        
        else if(Greenfoot.mouseClicked(medio)){
            Greenfoot.playSound("boton.mp3");
            Greenfoot.setWorld(new HistoriaM());
            sound.stop();
        }
        else  if(Greenfoot.mouseClicked(dificil)){
            Greenfoot.playSound("boton.mp3");
            Greenfoot.setWorld(new HistoriaH());
            sound.stop();
        } 
    }

    
    private void preparaMundo(){
        addObject(new Fondo(),300,200);
        addObject(facil,300,200);
        addObject(medio,300,250);
        addObject(dificil,300,300);
    }
}
