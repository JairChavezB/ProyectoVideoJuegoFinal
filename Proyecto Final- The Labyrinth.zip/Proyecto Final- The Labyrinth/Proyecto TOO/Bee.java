import greenfoot.*; 

/**
 * Está clase es el villano que aparecerá en el nivel 2 en la dificultad fácil 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class Bee extends Actor
{
    private int xPosition;
    private int horizontalMove=2;
    
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * La funcion prepara la imagen para que tenga el tamaño adecuado en el mundo
     */
    public Bee(){
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()/22;
        int myNewWidth = (int)myImage.getWidth()/22;
        myImage.scale(myNewWidth, myNewHeight);
    }
    
   public void act(){
        move();
    }
    
   /**
    * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * La funcion hace que la abeja se mueva y al momento de tocar la pared o el objeto door realice un giro
     */
   private void move(){
        move(1);
        
        Actor actor = getOneIntersectingObject (Door.class);
        if((actor != null)){
            turn(10);
        }
        
        actor = getOneIntersectingObject (ParedL2.class);
        if((actor != null)){
            turn(10);
        }
    }
    
    
    
}
