import greenfoot.*;  
import java.time.*;   

/**
 * Está clase nos mostrará la pantalla final después de terminar el videojuego en la dificultad díficil
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */ 

public class FinallyH extends World
{
    private int levelRestart;
    private Instant start;
    private Instant end;
    private static long timeLevel3;
    private GreenfootSound sound;
    private String song;
    
    
    public FinallyH(int levelRestart)
    {    
        super(600, 400, 1);
        this.start = start;
        this.end = end;
        
        song = "levelup.mp3";
        sound = new GreenfootSound(song);
        EndHomeH home = new EndHomeH();
        addObject(home,550,350);
        prepare();
        
    }
    
    public void prepare(){
        sound.play();
        addObject(new Message3(),300,100);
        Auro auro = new Auro();
        addObject(auro,300,300);
    }
}
