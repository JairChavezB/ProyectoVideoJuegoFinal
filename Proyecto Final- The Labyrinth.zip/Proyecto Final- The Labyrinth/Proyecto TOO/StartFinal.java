import greenfoot.*;  

/**
 * Está clase nos mostrará la pantalla de inicio para el nivel final en la dificultad fácil 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class StartFinal extends World
{
    
    public StartFinal()
    {   
        super(600, 400, 1);
        Greenfoot.playSound("levelup.mp3");
        
        prepare();
        
        Arrow arrow = new Arrow("LevelFinal");
        addObject(arrow,550,350);
    }
    
    /*@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * La funcion acomoda los actores necesarios dentro del world
     */
    public void prepare(){
        IntroF introf = new IntroF();
        addObject(introf,300,200);
        LevelF levelf = new LevelF();
        addObject(levelf,300,50);
    }
}
