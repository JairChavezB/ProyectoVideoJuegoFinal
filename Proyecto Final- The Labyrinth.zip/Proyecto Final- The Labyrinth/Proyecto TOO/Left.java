import greenfoot.*;  
public class Left extends Actor
{
    public void act()
    {
        
    }
}
