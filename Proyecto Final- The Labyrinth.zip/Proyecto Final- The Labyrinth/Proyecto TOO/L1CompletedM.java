import greenfoot.*; 

/**
 * Está clase nos mostrará la pantalla de que el nivel 1 ha sido completado exitosamente en la dificultad media 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class L1CompletedM extends World
{
    private long score1;
    private static long pointsL1;
    
    public L1CompletedM(long score1)
    {    
        super(600, 400, 1);
        
        prepare();
        
        Arrow arrow = new Arrow("MissionM");
        addObject(arrow,550,350);
        
        MenuP menuP = new MenuP("Menu");
        addObject(menuP,450,350);
        
        pointsL1 = score1;
    }
    
    public void prepare(){
        Greenfoot.playSound("levelup.mp3");
        addObject( new PlayerCompleted(),150,200);
        addObject( new Message(),350,120);
    }
    
    public static long getScore(){
        return pointsL1;
    }
}
