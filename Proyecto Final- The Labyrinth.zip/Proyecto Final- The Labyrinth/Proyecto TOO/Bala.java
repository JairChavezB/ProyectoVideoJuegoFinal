import greenfoot.*; 

/**
 * Está clase aparecerá en el nivel final y será la bala que mata al jefe final
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class Bala extends Actor
{
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * La funcion prepara la imagen para que tenga el tamaño adecuado 
     */
    public Bala(){
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()/8;
        int myNewWidth = (int)myImage.getWidth()/8;
        myImage.scale(myNewWidth, myNewHeight);
    }
    
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * La funcion hace que la bala se mueva horizontalmente y al momento que sale de los rangos desaparece 
     */
    public void act()
    {
        move(10);

        if(getX()<5 || getX()>590){
            getWorld().removeObject(this);
        }
    }
}
