import greenfoot.*; 

/**
 * Está clase se mostrará cada que el jugador pierda dentro de cualquier nivel
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */  
public class GameOver extends World
{
    Home home = new Home();
    private GreenfootSound sound;
    private String song;
    public GameOver()
    {    
        super(600, 400, 1); 
        song = "lost.mp3";
        sound = new GreenfootSound(song);
        prepareGameOver();
    }
    
    /**@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * La funcion agrega sonido para el botón 
     */
    public void act(){
        if(Greenfoot.mouseClicked(home)){
            Greenfoot.playSound("boton.mp3");
            Greenfoot.setWorld(new Menu());
        }
    }
    
    /**@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * La funcion prepara los objetos, actores que van en el world
     */
    public void prepareGameOver(){
        addObject(home,550,350);
        sound.play();
    }
}
