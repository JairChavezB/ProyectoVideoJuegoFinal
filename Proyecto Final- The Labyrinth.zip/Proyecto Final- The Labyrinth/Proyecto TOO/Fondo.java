import greenfoot.*;  

public class Fondo extends Actor
{
    public void act()
    {
        
    }
}
