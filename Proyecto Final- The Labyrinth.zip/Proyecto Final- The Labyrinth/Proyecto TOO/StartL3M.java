import greenfoot.*;  

/**
 * Está clase nos mostrará la pantalla de inicio para el nivel 3 en la dificultad media 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class StartL3M extends World
{
    private GreenfootSound sound;
    private String song;
    
    public StartL3M()
    {    
        super(600, 400, 1); 
        song = "levelup.mp3";
        sound = new GreenfootSound(song);
        prepare();
        
        Arrow arrow = new Arrow("Level3M");
        addObject(arrow,550,350);
    }
    
    /*@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * La funcion acomoda los actores necesarios dentro del world
     */
    public void prepare(){
        sound.play();
        IntroL3 intro3 = new IntroL3();
        addObject(intro3,300,200);
        LevelThree level3 = new LevelThree();
        addObject(level3,300,50);
    }
}
