import greenfoot.*;  
public class Message extends Actor
{
    public void act()
    {
        
    }
}
