import greenfoot.*;

/**
 * Está clase aparecerá en distintos mundos y nos ayudará a avanzar entre los niveles 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class Next extends Button
{
    private int level;
    
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * @param Indica el mundo del nivel que sigue 
     */
    public Next(int level)
    {    
        super(); 
        this.level = level;
        clickButton();
    }
    
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * Se le asignaron diferentes casos para reutilizar el actor en diferentes worlds 
     */
    public void clickButton(){
        
        if(Greenfoot.mouseClicked(this)){
            Greenfoot.delay(10);
            switch(level){
                case 0:
                    Greenfoot.setWorld(new Menu());
                    break;
                case 1:
                    Greenfoot.setWorld(new StartL1());
                    break;
                case 2:
                    Greenfoot.setWorld(new StartL2());
                    break;
                case 3:
                    Greenfoot.setWorld(new StartL3());
                    break;
                case 4:
                    Greenfoot.setWorld(new StartFinal());
                    break;
                case 5:
                    Greenfoot.setWorld(new StartL2M());
                    break;
                case 6:
                    Greenfoot.setWorld(new StartL3M());
                    break;
                case 7:
                    Greenfoot.setWorld(new StartFinalM());
                    break;
                case 8:
                    Greenfoot.setWorld(new StartL2H());
                    break;
                case 9:
                    Greenfoot.setWorld(new StartL3H());
                    break;
                case 10:
                    Greenfoot.setWorld(new StartFinalH());
                    break;
            }
        }
    }
}
