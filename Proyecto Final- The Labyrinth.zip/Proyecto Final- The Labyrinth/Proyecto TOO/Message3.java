import greenfoot.*;   
public class Message3 extends Actor
{
    public void act()
    {
    
    }
}
