import greenfoot.*;  
public class PlayerCompleted extends Actor
{
    public void act()
    {
        
    }
}
