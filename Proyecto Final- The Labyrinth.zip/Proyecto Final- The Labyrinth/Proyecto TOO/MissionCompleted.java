import greenfoot.*;  

/**
 * Está clase nos mostrará la pantalla con un mensaje de misión completada, está pantalla nos llevará a los siguientes niveles
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class MissionCompleted extends World
{
    private int levelRestart;
    private int nextLevel;
        
    public MissionCompleted(int levelRestart, int nextLevel)
    {    
        super(600, 400, 1); 
        this.levelRestart = levelRestart;
        this.nextLevel=nextLevel;
        prepare();
    }
    
    private void prepare()
    {
        Next next = new Next(nextLevel);
        addObject(next,500,360);
    
        MenuP menuP = new MenuP("Menu");
        addObject(menuP,500,303);
        
        Completed mission = new Completed();
        addObject(mission,300,150);
        
    }
}
