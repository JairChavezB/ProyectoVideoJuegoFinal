import greenfoot.*;

/**
 * Está clase nos ayudará a construir el mundo del nivel 2 en la dificultad difícil 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class Level2H extends World
{
    public Level2H()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepareLevel2();
    }
    
    /*@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * La funcion inserta los actores necesarios para el world nivel 2 dificil
     */
    private void prepareLevel2(){
        addObject(new Player2H(),50,60);
        addObject(new Door(),565,320);
        
        addObject(new BeeH(),110,120);
        addObject(new BeeH(),150,170);
        addObject(new BeeH(),520,220);
        addObject(new BeeN(),60,330);
        addObject(new BeeN(),250,60);
        
        for(int x = 250; x<320; x+=28){
            Coin coin = new Coin();
            addObject(coin,x,170);
        }
        
        for(int x = 300; x<400; x+=28){
            Coin coin = new Coin();
            addObject(coin,x,330);
        }
        
        for(int x = 235; x<305; x+=28){
            Coin coin = new Coin();
            addObject(coin,x,100);
        }
        
        for(int y = 200; y<280; y+=28){
            Coin coin = new Coin();
            addObject(coin,60,y);
        }
        
        for(int y = 170; y<250; y+=28){
            Coin coin = new Coin();
            addObject(coin,370,y);
        }
        
        for(int y = 170; y<300; y+=28){
            Coin coin = new Coin();
            addObject(coin,460,y);
        }
        
        
        
        for(int x = 15; x<700; x+=28){
            ParedL2 paredL2 = new ParedL2();
            addObject(paredL2,x,20);
            paredL2 = new ParedL2();
            addObject(paredL2,x,380);
        }
        
        for(int y = 50; y<365; y+=28){
            ParedL2 paredL2 = new ParedL2();
            addObject(paredL2,10,y);
        }
        
        for(int y = 50; y<360; y+=28){
            ParedL2 paredL2 = new ParedL2();
            addObject(paredL2,590,y);
        }
        
        for(int x = 50; x<130; x+=28){
            ParedL2 paredl2 = new ParedL2();
            addObject(paredl2,200,x);
            paredl2 = new ParedL2();
            addObject(paredl2,x,150);
            
        }
        
        for(int x = 90; x<320; x+=28){
            ParedL2 paredL2 = new ParedL2();
            addObject(paredL2,x,300);
        }
        
        for(int x = 200; x<330; x+=28){
            ParedL2 paredL2 = new ParedL2();
            addObject(paredL2,x,130);
        }
        
        for(int y = 120; y<300; y+=28){
            ParedL2 paredL2 = new ParedL2();
            addObject(paredL2,330,y);
        }
        
        for(int y = 180; y<220; y+=28){
            ParedL2 paredL2 = new ParedL2();
            addObject(paredL2,120,y);
        }
        
        for(int y = 110; y<350; y+=28){
            ParedL2 paredL2 = new ParedL2();
            addObject(paredL2,420,y);
        }
        
        for(int x = 450; x<510; x+=28){
            ParedL2 paredL2 = new ParedL2();
            addObject(paredL2,x,100);
        }
        
        for(int x = 150; x<240; x+=28){//
            ParedL2 paredL2 = new ParedL2();
            addObject(paredL2,x,215);
        }
        
        for(int x = 500; x<600; x+=28){
            ParedL2 paredL2 = new ParedL2();
            addObject(paredL2,x,200);
        }
        
        for(int x = 500; x<600; x+=28){
            ParedL2 paredL2 = new ParedL2();
            addObject(paredL2,x,280);
        }
    }
}
