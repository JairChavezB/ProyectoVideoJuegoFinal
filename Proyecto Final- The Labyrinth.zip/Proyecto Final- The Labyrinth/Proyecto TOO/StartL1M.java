import greenfoot.*;  

/**
 * Está clase nos mostrará la pantalla de inicio para el nivel 1 en la dificultad media 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class StartL1M extends World
{
    
    public StartL1M()
    {   
        super(600, 400, 1);
        Greenfoot.playSound("levelup.mp3");
        
        prepare();
        
        Arrow arrow = new Arrow("Level1M");
        addObject(arrow,550,350);
    }
    
    public void prepare(){
        IntroL1 intro1 = new IntroL1();
        addObject(intro1,300,200);
        LevelOne level1 = new LevelOne();
        addObject(level1,300,50);
    }
}
