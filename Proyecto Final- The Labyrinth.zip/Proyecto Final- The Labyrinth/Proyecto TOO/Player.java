import greenfoot.*;  

/** 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 * 
 * Esta clase es el player que aparecerá en el nivel 1 en dificultad fácil
 */
public class Player extends Actor
{
    private GreenfootSound sound;
    private String song;
    
    private static final int MAX_COUNTER_IMAGE = 10;
    private static final int MAX_COUNTER_MOVEMENT = 3;
    private static final int OFFSET = 10;
    
    public int score;
    private int life =200;
    private long pointsL1;
    
    private static final int UP = 0;
    private static final int DOWN = 1;
    private static final int RIGHT = 2;
    private static final int LEFT = 3;
    
    private int currentImage;
    private int counterImage;
    private int offsetX=0;
    private int offsetY=0;
    private int counterMovement;
    private int direction;
    private int frame=0;
    private int lastButtonPress;
    private boolean standingStill;
    
    
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * La funcion prepara la imagen para que tenga el tamaño adecuado en el mundo y la musica del nivel
     */
    public Player(){
        setImage("images/Aventurera/mov7.png");
        song = "musica.mp3";
        sound = new GreenfootSound(song);
    }
    
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * La funcion ayuda a que cuando la vida sea cero es GameOver
     */
    public void act()
    {
        sound.play();
        if(life<=0){
            sound.stop();
            Greenfoot.setWorld(new GameOver());
        }
       showHud();
       moveIfNoCollision(offsetX, offsetY);
       eatItems();
    }
    
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * Esta funcion muestra en pantalla el score y la vida del jugador
     */
    private void showHud(){
        getWorld().showText(Integer.toString(score), 580, 10);
        getWorld().showText("Score: ", 530, 10);
        
        getWorld().showText(Integer.toString(life), 70, 10);
        getWorld().showText("Life: ", 30, 10);
    }
    
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * Con esta funcion se realizan los movimientos del jugador
     */
    private void Movement(){
        standingStill=true;
        if(Greenfoot.isKeyDown("UP"))
        {
            movementUp();
            offsetX=0;
            offsetY=-OFFSET;
            direction=UP;
            lastButtonPress=1;
            standingStill=false;
        }else if(Greenfoot.isKeyDown("DOWN")){
            movementDown();
            offsetX=0;
            offsetY=OFFSET;
            direction=DOWN;
            lastButtonPress=2;
            standingStill=false;
        }else if(Greenfoot.isKeyDown("RIGHT"))
        {
            movementRight();
            offsetY=0;
            offsetX=OFFSET;
            direction=RIGHT;
            lastButtonPress=3;
            standingStill=false;
        }else if(Greenfoot.isKeyDown("LEFT")){
            movementLeft();
            offsetY=0;
            offsetX=-OFFSET;
            direction=LEFT;
            lastButtonPress=4;
            standingStill=false;
        }
        
        if(standingStill==true){
            if(lastButtonPress==1){
                setImage("images/Aventurera/mov1.png");
            }else if(lastButtonPress==2){
                setImage("images/Aventurera/mov7.png");
            }else if(lastButtonPress==3){
                setImage("images/Aventurera/mov10.png");
            }else if(lastButtonPress==4){
                setImage("images/Aventurera/mov4.png");
            }
        }
    }
    
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * @param Indica el la posicion tanto en X como en Y en el world en el que se encuentra 
     * 
     * La funcion hace que el jugador choque con la pared del nivel
     */
    private void moveIfNoCollision(int dx, int dy){
        counterMovement++;
        
        if(counterMovement < MAX_COUNTER_MOVEMENT){
            return;
        }
        
        int currentX = getX();
        int currentY = getY();
        
        counterMovement=0;
        Movement();
        
        setLocation(currentX + offsetX, currentY+offsetY);
        
        offsetY=0;
        offsetX=0;
        
        Actor wall = getOneIntersectingObject(Pared.class);
        if(wall!=null){
            setLocation(currentX + offsetX, currentY+offsetY);
        }
    }
    
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * Con esta funcion prepara las imagenes de los movimientos del jugador hacia la derecha
     */
    private void movementRight()
    {
        if(frame==0){
            setImage("images/Aventurera/mov10.png");
        }else if(frame==1){
            setImage("images/Aventurera/mov11.png");
        }else if(frame==2){
            setImage("images/Aventurera/mov12.png");
            frame=0;
            return;
        }
        frame++;
    }
    
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * Con esta funcion prepara las imagenes de los movimientos del jugador hacia la izquierda
     */
    private void movementLeft()
    {
        if(frame==0){
            setImage("images/Aventurera/mov4.png");
        }else if(frame==1){
            setImage("images/Aventurera/mov5.png");
        }else if(frame==2){
            setImage("images/Aventurera/mov6.png");
            frame=0;
            return;
        }
        frame++;
    }
    
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * Con esta funcion prepara las imagenes de los movimientos del jugador hacia arriba
     */
    private void movementUp()
    {
        if(frame==0){
            setImage("images/Aventurera/mov1.png");
        }else if(frame==1){
            setImage("images/Aventurera/mov2.png");
        }else if(frame==2){
            setImage("images/Aventurera/mov3.png");
            frame=0;
            return;
        }
        frame++;
    }
    
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * Con esta funcion prepara las imagenes de los movimientos del jugador hacia abajo
     */
    private void movementDown()
    {
        if(frame==0){
            setImage("images/Aventurera/mov7.png");
        }else if(frame==1){
            setImage("images/Aventurera/mov8.png");
        }else if(frame==2){
            setImage("images/Aventurera/mov9.png");
            frame=0;
            return;
        }
        frame++;
    }
    
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * Esta funcion hace que al momento de tocar a los enemigos al jugador le haga algun daño
     * Otra funcion que tiene es que al momento de tocar las monedas sume puntos
     * O al momento de tocar la puerta pase al siguiente nivel
     */
    private void eatItems(){
        Actor actor = getOneIntersectingObject (Coin.class);
        
        if(actor != null){
            Greenfoot.playSound("mario-coin.mp3");
            score+=50;
            getWorld().removeObject(actor);
        }
        
        actor = getOneIntersectingObject (Snake.class);
        
        if(actor != null){
            score -= 0.5;
            life -=0.5;
        }
        
        actor = getOneIntersectingObject (SnakeM.class);
        
        if(actor != null){
            score -= 2;
            life -=2;
        }
        
        actor = getOneIntersectingObject (SnakeH.class);
        
        if(actor != null){
            score -= 3;
            life -=3;
        }
        
        actor = getOneIntersectingObject (SnakeN.class);
        
        if(actor != null){
            score -= 0.5;
            life -=0.5;
        }
        
        actor = getOneIntersectingObject (Door.class);
        
        if(actor != null){
            pointsL1 = score;
            Greenfoot.setWorld(new L1Completed(pointsL1));
            sound.stop();
        }
    }
}
