import greenfoot.*;  

/**
 * Está clase aparecerá en menú y nos ayudará a poder terminar el juego
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class Exit extends Actor
{
    public void act()
    {
        if(Greenfoot.mouseClicked(this)){
            Greenfoot.playSound("boton.mp3");
            Greenfoot.stop();
        }
    }
}
