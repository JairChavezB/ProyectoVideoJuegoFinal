import greenfoot.*;  

/**
 * Está clase nos mostrará la pantalla de que el nivel 3 ha sido completado exitosamente en la dificultad media 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class L3CompletedM extends World
{
    private long score3;
    private static long pointsL3;
    Home home = new Home();
    
    public L3CompletedM(long score3)
    {    
        super(600, 400, 1);
        prepare();
        
        Arrow arrow = new Arrow("Mission3M");
        addObject(arrow,550,350);
        pointsL3 = score3;
    }
    
    public void act(){
        if(Greenfoot.mouseClicked(home)){
            Greenfoot.playSound("boton.mp3");
            Greenfoot.setWorld(new Menu());
        }
    }
    
    public void prepare(){
        Greenfoot.playSound("levelup.mp3");
        addObject( new PlayerCompleted(),150,200);
        addObject( new MessageFinal(),350,120);
        addObject(home,450,350);
    }
    
    public static long getScore(){
        return pointsL3;
    }
}
