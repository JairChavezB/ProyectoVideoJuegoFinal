import greenfoot.*;
import javax.swing.JOptionPane;

/**
 * Está clase es el botón con el cuál finalizaremos el juego y realiza la sumatoria de puntos en la dificultad difícil 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class EndHomeH extends Button
{
    private long totalScore;

    public void act()
    {
       clickButton();
    }
    
    
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * Al momento de presionar el actor con el click realiza la sumatoria de puntos de todos los niveles en difícil
     * La funcion pide tu nombre y la guarda para los records 
     */
    public void clickButton(){
        totalScore=(L1CompletedH.getScore()+L2CompletedH.getScore()+L3CompletedH.getScore());

        if(Greenfoot.mousePressed(this)){
            getImage().scale((int)Math.round(getImage().getWidth()*0.9),(int)Math.round(getImage().getHeight()*0.9));
        }

        if(Greenfoot.mouseClicked(this)){
            String inputValue=JOptionPane.showInputDialog("Please enter your name:");

            Greenfoot.setWorld(new Records(inputValue,totalScore));
        }
    }
}
