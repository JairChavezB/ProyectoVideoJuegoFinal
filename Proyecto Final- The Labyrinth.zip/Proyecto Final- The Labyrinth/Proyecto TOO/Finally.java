import greenfoot.*;  
import java.time.*;   

/**
 * Está clase nos mostrará la pantalla final después de terminar el videojuego en la dificultad fácil
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */ 

public class Finally extends World
{
    private int levelRestart;
    private Instant start;
    private Instant end;
    private static long timeLevel3;
    private GreenfootSound sound;
    private String song;
    
    /**@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * @param Indica el numero de niveles traspasados
     * La funcion realiza la inserción de imágenes que indican los cotroles a utilizar en el juego
     */
    public Finally(int levelRestart)
    {    
        super(600, 400, 1);
        this.start = start;
        this.end = end;
        
        song = "levelup.mp3";
        sound = new GreenfootSound(song);
        EndHome home = new EndHome();
        addObject(home,550,350);
        prepare();
        
    }
    
    /**@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * La funcion prepara el mundo de Finally agregando los actores
     */
    public void prepare(){
        sound.play();
        addObject(new Message3(),300,100);
        Auro auro = new Auro();
        addObject(auro,300,300);
    }
}
