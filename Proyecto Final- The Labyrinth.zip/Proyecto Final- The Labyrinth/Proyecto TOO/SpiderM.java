import greenfoot.*;  

/**
 * Está clase es el villano que aparecerá en el nivel 3 en la dificultad media 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class SpiderM extends Actor
{
   private int xPosition;
    private int horizontalMove=2;
    private int life = 6;
    
    public SpiderM(){
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()/30;
        int myNewWidth = (int)myImage.getWidth()/30;
        myImage.scale(myNewWidth, myNewHeight);
    }
    
    public void act(){
        if(life ==0){
            getWorld().removeObject(this);
        }
        move();
    }
    
    private void move(){
        move(1);
        
        Actor actor2 = getOneIntersectingObject (Door.class);
        Actor actor = getOneIntersectingObject (ParedL3.class);
        if((actor != null)){
            turn(10);
        }
        
        if((actor2 != null)){
            turn(20);
        }
    }
    
    public void add(int score)
    {
        life += score;
    }
    
    public int getValue()
    {
        return life;
    }
    
}
