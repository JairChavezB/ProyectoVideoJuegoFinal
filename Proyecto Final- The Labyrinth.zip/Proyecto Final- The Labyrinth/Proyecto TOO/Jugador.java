import greenfoot.*;  

/**
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class Jugador extends Actor
{private String nombre;
    private long totalTime;

    public void act(){
    }

    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * @param Indica el nombre del jugador y el puntaje que obtuvo en el juego
     */
    public Jugador(String nombre,long totalTime){
        this.nombre=nombre;
        this.totalTime=totalTime;
    }

    public Jugador(){

    }

    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * Regresa el nombre del jugador
     */
    public String getNombre(){
        return nombre;
    }

    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * Regresa el puntaje del jugador 
     */
    public long getTotalTime(){
        return totalTime;
    }
}
