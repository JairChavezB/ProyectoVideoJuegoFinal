import greenfoot.*;

/**
 * Está clase nos ayudará a construir el mundo del menú en el cual el jugador podrá iniciar el juego, ver los controles o salir del juego 
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class Menu extends World
{
    private GreenfootSound sound;
    private String song;
    Play play = new Play();
    Back back = new Back();
    Controls control = new Controls();
    private int opcion=0;
    private int y=200;
    String name;
    
    
    public Menu()
    {    
      
        super(600, 400, 1);
        song = "jungle.mp3";
        sound = new GreenfootSound(song);
        preparaMundo();
    }
    
    /*@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * La funcion acomoda los actores necesarios dentro del world
     */
    private void preparaMundo(){
        addObject(new Fondo(),300,200);
        addObject(play,300,200);
        addObject(control,300,250);
        addObject(new Exit(),300,300);
    }
    
    /*@author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * 
     * La funcion acomoda los actores necesarios dentro del world
     */
    public void act(){
        sound.play();
        if(Greenfoot.mouseClicked(play)){
            Greenfoot.playSound("boton.mp3");
            Greenfoot.setWorld(new Dificultad());
            sound.stop();
        }
        if(Greenfoot.mouseClicked(control)){
            Greenfoot.playSound("boton.mp3");
            Greenfoot.setWorld(new Control());
            sound.stop();
        }
    }
} 

    
  
