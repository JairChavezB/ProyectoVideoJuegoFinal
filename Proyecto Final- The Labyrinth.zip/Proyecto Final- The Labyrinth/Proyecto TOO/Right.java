import greenfoot.*;  
public class Right extends Actor
{
    public void act()
    {
        
    }
}
