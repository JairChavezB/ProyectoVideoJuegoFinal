import greenfoot.*;  
public class Up extends Actor
{
    public void act()
    {
      
    }
}
