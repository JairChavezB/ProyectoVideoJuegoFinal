import greenfoot.*;  

/**
 * Está clase es el villano que aparecerá en el nivel 2 de cualquier dificultad  
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class SnakeN extends Actor
{
    private int xPosition;
    private int horizontalMove=1;
    
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * La funcion prepara la imagen para que tenga el tamaño adecuado en el mundo
     */
    public SnakeN(){
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()/75;
        int myNewWidth = (int)myImage.getWidth()/75;
        myImage.scale(myNewWidth, myNewHeight);
    }
    
    public void act(){
        move();
    }
    
    /**
    * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * La funcion hace que la snake se mueva y al momento de tocar la pared realice un giro
     */
    public void move(){
        xPosition=getX();
        
        Actor actor = getOneIntersectingObject (Pared.class);
        if((actor != null)){
            horizontalMove *= -1;
        }
        
        setLocation(xPosition - horizontalMove,getY());
    }
    
    
}
