import greenfoot.*; 
 
/**
 * Está clase aparecerá en distintos mundos y nos ayudará a navergar entre algunos de ellos
 * 
 * @author De la Serna Rodríguez Miguel Ángel
 * @author Chavez Balderas Jair Israel
 * @version 02/06/2023
 */
public class Arrow extends Button
{
    private String world;
    private GreenfootSound sound;
    private String song;
    
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * @param Indica el mundo del nivel que sigue 
     */
    public Arrow(String world){
        super();
        this.world = world;
        song = "boton.mp3";
        sound = new GreenfootSound(song);
        
        clickButton();
    }
    
    
    /**
     * @author De la Serna Rodríguez Miguel Ángel
     * @author Chavez Balderas Jair Israel
     * @version 02/06/2023
     * Se le asignaron diferentes casos para reutilizar el actor en diferentes worlds 
     */
    public void clickButton(){
        
        if(Greenfoot.mouseClicked(this)){
            Greenfoot.delay(10);
            switch(world){
                case "Start1":
                    sound.play();
                    Greenfoot.setWorld(new StartL1());
                    break;
                case "StartM":
                    sound.play();
                    Greenfoot.setWorld(new StartL1M());
                    break;
                case "StartH":
                    sound.play();
                    Greenfoot.setWorld(new StartL1H());
                    break;
                case "Mission":
                    sound.play();
                    Greenfoot.setWorld(new MissionCompleted(1,2));
                    break;
                case "Mission2":
                    sound.play();
                    Greenfoot.setWorld(new MissionCompleted(2,3));
                    break;
                case "Mission3":
                    sound.play();
                    Greenfoot.setWorld(new MissionCompleted(3,4));
                    break;
                case "MissionM":
                    sound.play();
                    Greenfoot.setWorld(new MissionCompleted(4,5));
                    break;
                case "Mission2M":
                    sound.play();
                    Greenfoot.setWorld(new MissionCompleted(5,6));
                    break;
                case "Mission3M":
                    sound.play();
                    Greenfoot.setWorld(new MissionCompleted(6,7));
                    break;
                case "MissionH":
                    sound.play();
                    Greenfoot.setWorld(new MissionCompleted(7,8));
                    break;
                case "Mission2H":
                    sound.play();
                    Greenfoot.setWorld(new MissionCompleted(8,9));
                    break;
                case "Mission3H":
                    sound.play();
                    Greenfoot.setWorld(new MissionCompleted(9,10));
                    break;
                case "Level1":
                    sound.play();
                    Greenfoot.setWorld(new Level1());
                    break;
                case "Level1M":
                    sound.play();
                    Greenfoot.setWorld(new Level1M());
                    break;
                case "Level1H":
                    sound.play();
                    Greenfoot.setWorld(new Level1H());
                    break;
                case "Level2":
                    sound.play();
                    Greenfoot.setWorld(new Level2());
                    break;
                case "Level2M":
                    sound.play();
                    Greenfoot.setWorld(new Level2M());
                    break;
                case "Level2H":
                    sound.play();
                    Greenfoot.setWorld(new Level2H());
                    break;
                case "Level3":
                    sound.play();
                    Greenfoot.setWorld(new Level3());
                    break;
                case "Level3M":
                    sound.play();
                    Greenfoot.setWorld(new Level3M());
                    break;
                case "Level3H":
                    sound.play();
                    Greenfoot.setWorld(new Level3H());
                    break;
                case "LevelFinal":
                    sound.play();
                    Greenfoot.setWorld(new LevelFinal());
                    break;
                case "LevelFinalM":
                    sound.play();
                    Greenfoot.setWorld(new LevelFinalM());
                    break;
                case "LevelFinalH":
                    sound.play();
                    Greenfoot.setWorld(new LevelFinalH());
                    break;
            }
        }
    }
}
